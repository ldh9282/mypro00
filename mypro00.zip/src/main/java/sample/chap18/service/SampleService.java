package sample.chap18.service;

public interface SampleService {
	
	public Integer doAdd(String str1, String str2) throws Exception ;
}
